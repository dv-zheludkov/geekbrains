"""
Задание 5.

Выполнить пинг веб-ресурсов yandex.ru, youtube.com и
преобразовать результаты из байтовового в строковый тип на кириллице.

Подсказки:
--- используйте модуль chardet, иначе задание не засчитается!!!
"""

import subprocess
import chardet
#Так как в Mac OS по умолчанию пинг бесконечен, в список параметров добавлено ограничение на 5 пакетов
args = [['ping', 'yandex.ru', '-c', '5'], ['ping', 'youtube.com', '-c', '5']]
for arg in args:
    ping = subprocess.Popen(arg, stdout=subprocess.PIPE)
    for line in ping.stdout:
        result = chardet.detect(line)
        line = line.decode(result['encoding']).encode('utf-8')
        print(line.decode('utf-8'))